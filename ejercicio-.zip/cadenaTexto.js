let msg = "HOLA MUNDO"

let texto = msg.toLowerCase()
console.log(texto);
let msg = "A continuación le estoy entregando una cadena de texto que servirá como texto guía para realizar los siguientes ejercicios . "

let buscar = msg.includes('filtro');
console.log(buscar);
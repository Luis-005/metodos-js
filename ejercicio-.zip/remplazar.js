let msg = "A continuación le estoy entregando una cadena de texto que servirá como texto guía para realizar los siguientes ejercicios . "

const reemplazar = msg.split(' ').join('-')
console.log(reemplazar)
